function application () {
	this.currentUser = 0;
	this.tasks = [];
}

application.prototype.getUserTasks = function () {
	var curapp = this;

	BX24.callMethod(
		'task.item.list', 
		[],
		function(result) {
			if ( result.error() ) {
				displayErrorMessage('К сожалению, произошла ошибка получения задач. Попробуйте повторить позже');
				console.error(result.error());
			} else {
				var data = result.data();
				console.log('data', data);
				
				for ( var task in data ) {
					console.log(task.ID);
					curapp.tasks.push(data[task]);
				}
							
				if ( result.more() ) {
					result.next();
				} else {
					console.log('Получены все данные');
					console.log('tasks', curapp.tasks);

				}
					
			}
		}
	);	
}


application.prototype.showTasks = function () {
	var curapp = this;
	curapp.getUserTasks();
}

app = new application();
